package com.example.cardbinder

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Binder(
    val id: String,
    val name: String,
    val pages: MutableList<MutableList<String?>>
)

class BinderStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("card_binder", Context.MODE_PRIVATE)
    private val key = "binders"

    fun load(): MutableList<Binder> {
        val raw = prefs.getString(key, null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val pagesJson = o.getJSONArray("pages")
                val pages = MutableList(pagesJson.length()) { p ->
                    val slotsJson = pagesJson.getJSONArray(p)
                    MutableList(slotsJson.length()) { s ->
                        if (slotsJson.isNull(s)) null else slotsJson.getString(s)
                    }
                }
                Binder(o.getString("id"), o.getString("name"), pages)
            }
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun save(binders: List<Binder>) {
        val arr = JSONArray()
        binders.forEach { binder ->
            val o = JSONObject()
            o.put("id", binder.id)
            o.put("name", binder.name)
            val pages = JSONArray()
            binder.pages.forEach { page ->
                val slots = JSONArray()
                page.forEach { slot -> slots.put(slot ?: JSONObject.NULL) }
                pages.put(slots)
            }
            o.put("pages", pages)
            arr.put(o)
        }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    fun copyImageToApp(uri: Uri): String? {
        return try {
            val ext = context.contentResolver.getType(uri)?.substringAfterLast('/') ?: "jpg"
            val file = File(context.filesDir, "card_${UUID.randomUUID()}.$ext")
            context.contentResolver.openInputStream(uri)?.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            file.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    fun deleteImage(path: String?) {
        if (!path.isNullOrBlank()) File(path).delete()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CardBinderTheme {
                CardBinderApp(this)
            }
        }
    }
}

@Composable
fun CardBinderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = Color(0xFF42A5F5),
            background = Color(0xFF0B0B0B),
            surface = Color(0xFF171717)
        ),
        content = content
    )
}

@Composable
fun CardBinderApp(context: Context) {
    val store = remember { BinderStore(context) }
    var binders by remember { mutableStateOf(store.load()) }
    var selectedBinderId by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }

    val selected = binders.firstOrNull { it.id == selectedBinderId }

    if (selected == null) {
        HomeScreen(
            binders = binders,
            onOpen = { selectedBinderId = it.id },
            onCreate = { showCreate = true },
            onDelete = { binder ->
                binders = binders.filterNot { it.id == binder.id }.toMutableList()
                store.save(binders)
            }
        )
    } else {
        BinderScreen(
            binder = selected,
            store = store,
            onBack = { selectedBinderId = null },
            onChanged = {
                binders = binders.toMutableList()
                store.save(binders)
            }
        )
    }

    if (showCreate) {
        CreateBinderDialog(
            onDismiss = { showCreate = false },
            onCreate = { name ->
                val binder = Binder(
                    UUID.randomUUID().toString(),
                    name.ifBlank { "Mon classeur" },
                    mutableListOf(MutableList(9) { null })
                )
                binders = (binders + binder).toMutableList()
                store.save(binders)
                showCreate = false
                selectedBinderId = binder.id
            }
        )
    }
}

@Composable
fun HomeScreen(
    binders: List<Binder>,
    onOpen: (Binder) -> Unit,
    onCreate: () -> Unit,
    onDelete: (Binder) -> Unit
) {
    Scaffold(
        containerColor = Color(0xFF0B0B0B),
        floatingActionButton = {
            FloatingActionButton(onClick = onCreate) {
                Icon(Icons.Default.Add, contentDescription = "Nouveau classeur")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)
        ) {
            Text("CardBinder", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text(
                "Tes classeurs Pokémon et tes images, au même endroit.",
                color = Color.LightGray,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            if (binders.isEmpty()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.MenuBook, null, modifier = Modifier.size(52.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Aucun classeur pour le moment", fontWeight = FontWeight.Bold)
                        Text(
                            "Crée ton premier binder avec le bouton +.",
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(binders, key = { it.id }) { binder ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF191919)),
                            modifier = Modifier.fillMaxWidth().clickable { onOpen(binder) }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp, 82.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF202020))
                                        .border(2.dp, Color(0xFF303030), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Book, null, tint = Color(0xFF42A5F5))
                                }
                                Spacer(Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(binder.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    Text("${binder.pages.size} page(s) • 9 pochettes/page", color = Color.Gray)
                                }
                                IconButton(onClick = { onDelete(binder) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Supprimer")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BinderScreen(
    binder: Binder,
    store: BinderStore,
    onBack: () -> Unit,
    onChanged: () -> Unit
) {
    var pageIndex by remember { mutableIntStateOf(0) }
    var selectedSlot by remember { mutableIntStateOf(-1) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showRemoveDialog by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null && selectedSlot >= 0) {
            val path = store.copyImageToApp(uri)
            if (path != null) {
                val old = binder.pages[pageIndex][selectedSlot]
                store.deleteImage(old)
                binder.pages[pageIndex][selectedSlot] = path
                onChanged()
            }
        }
    }

    fun openSlot(index: Int) {
        selectedSlot = index
        showAddDialog = true
    }

    Scaffold(
        containerColor = Color(0xFF090909),
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Retour")
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(binder.name, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    Text("Page ${pageIndex + 1} / ${binder.pages.size}", color = Color.Gray, fontSize = 12.sp)
                }
                IconButton(onClick = {
                    binder.pages.add(MutableList(9) { null })
                    pageIndex = binder.pages.lastIndex
                    onChanged()
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Ajouter une page")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BinderPage(
                page = binder.pages[pageIndex],
                onSlotClick = ::openSlot,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { if (pageIndex > 0) pageIndex-- },
                    enabled = pageIndex > 0
                ) { Icon(Icons.Default.ArrowBack, "Page précédente") }

                Text("Page ${pageIndex + 1}", color = Color.LightGray)

                IconButton(
                    onClick = { if (pageIndex < binder.pages.lastIndex) pageIndex++ },
                    enabled = pageIndex < binder.pages.lastIndex
                ) { Icon(Icons.Default.ArrowForward, "Page suivante") }
            }
        }
    }

    if (showAddDialog) {
        val hasImage = selectedSlot >= 0 && binder.pages[pageIndex][selectedSlot] != null
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(if (hasImage) "Modifier cette pochette" else "Ajouter dans la pochette") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            showAddDialog = false
                            imagePicker.launch("image/*")
                        }
                    ) {
                        Icon(Icons.Default.PhotoLibrary, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Choisir une image")
                    }
                    if (hasImage) {
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                showAddDialog = false
                                showRemoveDialog = true
                            }
                        ) {
                            Icon(Icons.Default.Delete, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Retirer la carte")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Fermer") }
            }
        )
    }

    if (showRemoveDialog) {
        AlertDialog(
            onDismissRequest = { showRemoveDialog = false },
            title = { Text("Retirer l'image ?") },
            text = { Text("L'image sera retirée de cette pochette.") },
            confirmButton = {
                TextButton(onClick = {
                    val old = binder.pages[pageIndex][selectedSlot]
                    store.deleteImage(old)
                    binder.pages[pageIndex][selectedSlot] = null
                    showRemoveDialog = false
                    onChanged()
                }) { Text("Retirer") }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveDialog = false }) { Text("Annuler") }
            }
        )
    }
}

@Composable
fun BinderPage(
    page: List<String?>,
    onSlotClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // 3x3 binder page. The dark seams and rounded slots are intentionally
    // styled to evoke a black 9-pocket trading-card binder.
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF161616))
            .border(2.dp, Color(0xFF292929), RoundedCornerShape(12.dp))
            .padding(7.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for (row in 0 until 3) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (col in 0 until 3) {
                        val index = row * 3 + col
                        Pocket(
                            path = page[index],
                            onClick = { onSlotClick(index) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Pocket(
    path: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .aspectRatio(0.70f)
            .clip(RoundedCornerShape(7.dp))
            .background(Color(0xFF0D0D0D))
            .border(1.dp, Color(0xFF333333), RoundedCornerShape(7.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (path == null) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Add, null, tint = Color(0xFF777777), modifier = Modifier.size(28.dp))
                Text("Ajouter", color = Color(0xFF777777), fontSize = 11.sp)
            }
        } else {
            val bitmap = remember(path) { BitmapFactory.decodeFile(path) }
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Carte",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(Icons.Default.Image, null, tint = Color.Gray)
            }
        }
    }
}

@Composable
fun CreateBinderDialog(
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau classeur") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nom du classeur") },
                placeholder = { Text("Ex. Collection Pokémon") },
                singleLine = true
            )
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name) }) { Text("Créer") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        }
    )
}
