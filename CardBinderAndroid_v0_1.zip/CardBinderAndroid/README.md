# CardBinder — première version Android

Première version d'une application de classeurs virtuels pour cartes Pokémon et autres images.

## Fonctionnalités

- Accueil avec la liste des classeurs.
- Création et suppression de classeurs.
- Classeur avec pages 3 × 3 (9 pochettes).
- Ajout d'une image depuis la galerie dans une pochette.
- Remplacement ou retrait d'une image.
- Ajout de pages.
- Navigation page précédente / suivante.
- Les images sont copiées dans le stockage privé de l'application.
- Les classeurs sont sauvegardés localement.

## Ouvrir le projet

1. Installer Android Studio.
2. Ouvrir le dossier `CardBinderAndroid`.
3. Laisser Android Studio synchroniser Gradle.
4. Brancher un téléphone Android (ou utiliser un émulateur).
5. Appuyer sur Run.

Cette version ne contient pas d'images Pokémon officielles : tu ajoutes tes propres photos/images depuis la galerie.
